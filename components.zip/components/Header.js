import React from 'react'
import { FcAdvertising } from 'react-icons/fc';
import { MdMenu } from 'react-icons/md';
import { FaUserAlt } from 'react-icons/fa';

import NavBar from './NavBar';
import MobileNavBar from './MobileNavBar';


function Header() {
    return (
        <div className='w-[100%] h-fit flex justify-between items-center py-5 px-8 bg-white shadow-sm'>
            <div className='flex gap-x-3 items-center text-xl'>
                <FcAdvertising />
                <span>Hodan</span>
            </div>
            <div>
                <NavBar />
                <MobileNavBar />
            </div>
            <div
                className='border-2 border-white flex items-center gap-x-2 sm:py-1 sm:px-2 rounded-full cursor-pointer active:scale-95 shadow-xl'>
                <MdMenu className='hidden sm:block text-slate-700  text-2xl' />
                <FaUserAlt className=' p-2 text-3xl  sm:text-3xl bg-slate-200 sm:bg-gray-600 text-indigo-600 sm:text-white rounded-full' />
            </div>
        </div>
    )
}

export default Header
